package jeu;

public class BossMonster extends Monster {

	//Informations concernant le monstre boss: sa vitesse, ses points de vie, sa recompense, son apparence
	static final double SPEED_BOSSMONSTER = 0.06;
	static final int HP_BOSSMONSTER = 150;
	static final int REWARD_BOSSMONSTER = 50;
	final int level; 
	/**
	 * Constructeur du mosntre boss
	 * @param p la position du monstre
	 * @parem lvl le level joue par le joueur
	 */
	public BossMonster(Position p, int lvl) {
		super(p, SPEED_BOSSMONSTER, HP_BOSSMONSTER, REWARD_BOSSMONSTER, lvl);
		level = lvl;
	}

	/**
	 * Affiche un monstre boss
	 * Le monstre est representé par un ogre ou un triton
	 * @parem lvl le level joue par le joueur
	 */
	@Override
	public void draw() {
		switch(level) {
		case 1: StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/ogerboss/oger-boss.gif");
			break;
		case 2:StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/tritonboss/triton.gif");
			break;
		}
		
	}
}
