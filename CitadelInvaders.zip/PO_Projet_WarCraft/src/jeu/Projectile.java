package jeu;

public class Projectile {

	//POSITION ET DEPLACEMENT
	// Position du tireur
	Position shooter;
	// Position de la cible
	Position target;
	//Position du projectile
	Position p;
	//Velocite du projectile en sur l'axe x et l'axe y
	double xVelo, yVelo;
	//Boolean pour connaitre le sens de l'attaque:
	//true si le projectile est tire par une tour vers un monstre
	//false si le projectile est tire par un monstre vers une tour
	boolean atk;
	//Boolean pour savoir si le projectile a touche la cible
	boolean hit;
	
	//CARACTERISTIQUES
	//Degats de l'attaque 
	int damage; 
	//Vitesse du projectile 
	double speed; 
	//Boolean valant true si le projectile est un laser
	boolean isLaser;
	//Tour cible ou tireuse du projectile
	Tower tower;
	//Monstre cible ou tireur du projectile
	Monster monster;
	
	/**
	 * Constructeur d'un projectile
	 * @param tower la tour cible ou tireuse du projectile
	 * @param monster le monstre cible ou tireur du projectile
	 * @param atk le sens de l'attaque
	 */
	public Projectile(Tower tower, Monster monster, boolean atk) {
		this.tower = tower;
		this.monster = monster;
		this.atk = atk;
		if (atk) {
			this.p = new Position(tower.p.getX(), tower.p.getY());
			shooter = tower.p;
			target = monster.p;
			switch (tower.id) {
			case 1 :
				this.damage = 2 + tower.lvl;
				this.speed = 0.04 + tower.lvl*0.001;
				break;
			case 2 :
				this.damage = 8 + tower.lvl;
				this.speed = 0.02 + tower.lvl*0.001;
				break;
			case 3 :
				this.damage = 0 ;
				this.speed = 0.01 + tower.lvl*0.001;
				break;	
			case 4 :
				this.damage = 0;
				this.speed = 0.01 + tower.lvl*0.001;
				break;	
			case 5 :
				this.damage = 1 + tower.lvl/2;
				this.speed = 1;
				isLaser = true;
				break;
			}
		}
		else {
			this.p = new Position(monster.p.getX(), monster.p.getY());
			shooter = monster.p;
			target = tower.p;
			speed = 0.02;
			damage = monster.atk;
		}
		
		getDirection();
	}

	/**
	 * Donne la direction que le projectile doit suivre pour atteindre sa cible
	 * 
	 */
	public void getDirection() {
		double distance = Math.abs(p.getX() -target.getX()) + Math.abs(p.getY() - target.getY());
		xVelo =  Math.abs(p.getX() -target.getX()) / distance;
		yVelo = Math.abs(p.getY() -target.getY()) / distance;
		if (target.getX() < p.getX()) xVelo *= -1;
		if (target.getY() < p.getY()) yVelo *= -1;

	}

	/**
	 * Met a jour la position du projectile s'il n'a pas atteint sa cible
	 * S'il a atteint sa cible, celle-ci subit des degats ou des effets de statuts
	 */
	public void move() {
		if (Math.abs(p.getX() - target.getX())< 0.01 || Math.abs(p.getY() - target.getY())< 0.01){
			hit = true;
			if (atk) {
				monster.hp = monster.hp - damage;
				if(tower.id == 3) {
					this.monster.frozen = true;
					this.monster.frozenTimer = new Timer(3000 + tower.lvl * 1000);
				}
				if(tower.id == 4) {
					this.monster.burntTimer = new Timer(1000 - tower.lvl/2);
					this.monster.burntDuration = 2 + tower.lvl/2;
					this.monster.burntDamage = 1 + tower.lvl/2 ;
				}
			}
			else {
				tower.hp -= damage;
			}
		}
		else {
			double newX = p.getX() + speed * xVelo;
			double newY = p.getY() + speed  * yVelo;
			this.p = new Position(newX, newY);
		}
	}

	/**
	 * Permet de dessiner les projectiles
	 */
	public void draw() {
		if (atk) {
			String image = null;
			switch (tower.id) {
			case 1 : image = "jeu/image/Projectiles/Fleche/fleche.png";
				break;
			case 2 : image = "jeu/image/Projectiles/Bombe/bombe.gif";
				break;
			case 3 : image = "jeu/image/ProjectileFlocon/projectile-flocon.png";
				break;
			case 4 : StdDraw.setPenColor(StdDraw.BOOK_RED);
				break;
			} 
			if(image != null) StdDraw.picture(p.getX(), p.getY(), image);
			if(tower.id == 4) StdDraw.filledCircle(p.getX(), p.getY(), 0.01);
			if((tower.id == 5) && (tower.target != null)) StdDraw.line(tower.p.getX(), tower.p.getY(), monster.p.getX(), monster.p.getY());
		}
		else  {
			StdDraw.picture(p.getX(), p.getY(), "jeu/image/Projectiles/Bulle/bubulle.png");
		}
	}

	/**
	 * Met a jour un projectile, est utilisee dans Main
	 */
	public void update() {
		move();
	}

}
