package jeu;
public class FlyingMonster extends Monster {
	
	//Informations concernant le monstre volant: sa vitesse, ses points de vie, sa recompense et son apparence
	static final double SPEED_FLYINGMONSTER = 0.02;
	static final int HP_FLYINGMONSTER = 3;
	static final int REWARD_FLYINGMONSTER = 8;
	final int level;
	
	/**
	 * Constructeur du monstre volant
	 * @param p la position du monstre 
	 * @parem lvl le level joue par le joueur
	 */
	public FlyingMonster(Position p, int lvl) {
		super(p, SPEED_FLYINGMONSTER, HP_FLYINGMONSTER, REWARD_FLYINGMONSTER, lvl);
		level = lvl;
	}
	
	/**
	 * Constructeur du monstre volant apres la premiere vague
	 * @param p la postion du monstre
	 * @param modifier permet d'ajuster la difficulte en fonction de la vague
	 * @parem lvl le level joue par le joueur
	 */
	public FlyingMonster(Position p, int modifier, int lvl) {
		super(p, SPEED_FLYINGMONSTER + modifier * 0.01, HP_FLYINGMONSTER + modifier * 3 , REWARD_FLYINGMONSTER, lvl);
		level = lvl;
	}

	
	/**
	 * Affiche un monstre volant
	 * Le monstre est represente par une chauve-souris dans le level 1
	 * Le monstre est represente par un moustique dans le level 2
	 */
	@Override
	public void draw() {
		switch (level) {
		case 1: StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/Fliyngmonster/batman.gif");
			break;
		case 2:  StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/mosquito/mosquito.gif");
			break;
		}
		
	}

}
