package jeu;
public abstract class Monster {
	
	// Nombre de Monstres crees
	static int nbMonsters = 0;
	
	//POSTION ET DEPLACEMENT
	// Position du monstre a l'instant t
	Position p;
	// Position du debut du segment courant
	Position oldP;
	// Position de fin du segment courant
	Position nextP;
	// valeur du deplacement effectue a chaque iteration pour un segment donne
	Position dep;
	// index sur la liste des segments ou points extremites des segments du trajet
	int iterTrajet;
	// Boolean pour savoir si le monstre a atteint le chateau du joueur
	boolean reached;
	// Compteur de deplacement pour savoir quel monstre est le plus proche du chateau du joueur
	int checkpoint = 0; 
	
	//CARACTERISQUES DU MONSTRE
	// Nombre de point de vie du monstre
	int hp;
	// Vitesse du monstre
	double speed;
	// Pieces d'or que rapporte le monstre
	int reward;
	// Indique si le monstre est gele et le timer associe a la duree du gel
	boolean frozen;
	Timer frozenTimer;
	long frozenLeft;
	// Indique si le monstre est en feu et le timer associe a la duree du feu ainsi que sa puissance
	Timer burntTimer; // temps avant la prochaine "brulure"
	int burntDuration; // nombre de "brulure" restantes
	int burntDamage;
	long burntTLeft;
	int burntDLeft;
	// Pour le shooting monster: sa portee, temps de rechargement, attaque et sa cible
	double reach;
	int rec;
	int left;
	int atk;
	Tower target;
	
	//GRAPHIQUE
	int lvl; //permet de choisir l apparence du monstre en fonction du level
	

	/**
	 * Constructeur d'un monstre
	 * @param p la position du monstre
	 * @param speed la vitesse du monstre
	 * @param hp les points de vie du monstre
	 * @param reward la recompense du monstre
	 * @param lvl le level joue par le joueur
	 */
	public Monster(Position p, double speed, int hp, int reward, int lvl) {
		nbMonsters++;
		
		iterTrajet = 0; // cellule N 0
		this.p = new Position((Chemin.trajet.getPxy()).get(iterTrajet));
		this.oldP = new Position((Chemin.trajet.getPxy()).get(iterTrajet));
		iterTrajet = 1; // cellule N 1
		this.nextP = new Position((Chemin.trajet.getPxy()).get(iterTrajet)); // second point du trajet
		this.dep = Position.dep((nextP.getX() - oldP.getX()) * speed, (nextP.getY() - oldP.getY()) * speed);
		this.reached = false;
		this.checkpoint = 0;
		
		this.speed = speed;
		this.hp = hp;
		this.reward = reward;
		this.frozen = false;
		this.burntDuration = 0;
		this.burntTimer = new Timer(0);
		
		this.lvl = lvl;
	}
	
	/**
	 * Constructeur utilise par le shooting monster
	 * 
	 * @param p la position du monstre
	 * @param speed la vitesse du monstre
	 * @param hp les points de vie du monstre
	 * @param reward la recompense du monstre
	 * @param reach la portee du shooting monster
	 * @param rec le temps entre chaque attaque du shooting monster
	 * @param atk l'attaque du shooting monster
	 * @param lvl le level joue par le joueur
	 */
	public Monster(Position p, double speed, int hp, int reward, double reach, int rec, int atk, int lvl) {
		nbMonsters++;
		
		iterTrajet = 0; // cellule N 0 
		this.p = new Position((Chemin.trajet.getPxy()).get(iterTrajet));
		this.oldP = new Position((Chemin.trajet.getPxy()).get(iterTrajet));
		iterTrajet = 1; // cellule N 1
		this.nextP = new Position((Chemin.trajet.getPxy()).get(iterTrajet)); // second point du trajet
		this.dep = Position.dep((nextP.getX() - oldP.getX()) * speed, (nextP.getY() - oldP.getY()) * speed);
		this.reached = false;
		this.checkpoint = 0;
		
		this.speed = speed;
		this.hp = hp;
		this.reward = reward;
		this.frozen = false;
		this.burntDuration = 0;
		this.burntTimer = new Timer(0);
		this.reach = reach;
		this.rec = rec;
		this.left = 0;
		this.atk = atk;
	
		this.lvl = lvl;
	}

	/**
	 * Deplace le monstre en fonction de sa vitesse sur l'axe des x et des y et de
	 * sa prochaine position.
	 */
	public void move() {
		if (!reached) {
			// changement de segment (et de cellule)
			if (p.equals(nextP)) {
				reached = (iterTrajet == ((Chemin.trajet.getPxy()).size() - 1)); // la derniere cellule a ete parcourue
				if ((iterTrajet < (Chemin.trajet.getPxy()).size() - 1)) { // pas encore au dernier segment
					// point de depart sur le segment
					this.oldP = new Position((Chemin.trajet.getPxy()).get(iterTrajet));
					iterTrajet++; // Position suivante (=centre cellule suivante)
					// point arrivee sur le segment
					this.nextP = new Position((Chemin.trajet.getPxy()).get(iterTrajet)); // second point du trajet
					// actualise la position
					this.dep = Position.dep((nextP.getX() - oldP.getX()) * speed, (nextP.getY() - oldP.getY()) * speed);
					p.setX(oldP.getX());
					p.setY(oldP.getY());
				}
			}
			if (!reached) {	// traitement cas particulier derniere cellule rend le test necessaire
				// deplacement sur le segment a chaque iteration
				p.setX(p.getX() + dep.getX());
				p.setY(p.getY() + dep.getY());
			}
		}
	}

	/**
	 * Met a jour la position du monstre s'il n'est pas glace
	 * Le monstre peut subir des degats s'il est brule
	 * Met a jour le statut du monstre(glace, brule, temps avant la prochaine attaque)
	 */
	public void update() {
		if ((frozen) && (frozenTimer.hasFinished())) frozen = false;
		if ((burntTimer.hasFinished()) && (burntDuration != 0)) {
			hp -= burntDamage;
			burntDuration-- ;
			burntTimer.restart();
		}
		if(!this.frozen) {
			move();
			if((getClass() == ShootingMonster.class) && (left > 0)) left--;
		}
		if(burntDuration != 0) {
			StdDraw.setPenColor(StdDraw.BOOK_RED);
			StdDraw.filledCircle(p.getX(), p.getY(), 0.01);
		}
		if(frozen) {
			StdDraw.setPenColor(StdDraw.BOOK_LIGHT_BLUE);
			StdDraw.filledCircle(p.getX(), p.getY(), 0.01);
		}
		checkpoint++; 
	}
	
	/**
	 * Fonction abstraite qui sera instanciee dans les classes filles pour afficher
	 * le monstre sur le plateau de jeu.
	 */
	public abstract void draw();
}
