package jeu;
public abstract class Tower {
	
	//CARACTERISTIQUES
	//Position de la tour
	Position p;
	//Prix de la tour en or
	int cost;
	//Temps de rechargement de la tour 
	int rec;
	//Temps de rechargement de la tour avant prochaine attaque
	int left;
	//Portee de la tour
	double reach;
	//Niveau de la tour
	int lvl;
	//Points de vie maximum de la tour
	int hpmax;
	//Points de vie de la tour 
	int hp;
	//Bololean statut de la tour (true = fonctionnelle) (false = endommagee)
	boolean statut;
	
	//POUR LES ATTAQUES
	//Cible de la tour
	Monster target;
	//Checkpoint du monstre avec le plus haut checkpoint des monstres a portee de tir
	int checkpointMax;
	//Type de la tour (ID)
	int id;
	
	/**
	 * Constructeur d'une tour
	 * @param p la position de la tour
	 * @param cost le cout de la tour
	 * @param rec le temps de rechargement de la tour
	 * @param reach la portee de la tour
	 * @param id l'identifiant de la tour
	 * @param hpmax les points de vie maximum de la tour
	 */
	public Tower(Position p, int cost, int rec, double reach, int id, int hpmax) {
		this.p = p;
		this.cost = cost;
		this.rec = rec;
		left = 0;
		this.reach = reach;
		lvl = 0;
		target = null;
		checkpointMax = 0;
		this.id = id;
		this.hpmax = hpmax;
		this.hp = hpmax;
		this.statut = true;
	}
	/**
	 * Modifie les caracteristique de la tour lorsque le joueur veut lui faire gagner un niveau
	 */
	public void levelUp () {
		lvl++ ;
		reach += lvl*0.001;
		hpmax += 10;
		System.out.println("Tower leveled up !");
	}
	
	/**
	 * Modifie le statut de la tour lorsque le joueur veut la reparer
	 */
	public void repair() {
		statut = true;
		hp = hpmax;
		System.out.println("Tower repaired !");
	}
	
	/**
	 * Met a jour la tour en actualisant son statut et le temps avant sa prochaine attaque
	 */
	public void update() {
		if ((hp > 0) && (left > 0)) left--;
		if(hp <= 0) statut = false;
	}
	
	/**
	 * Fonction  qui sert a afficher la tour sur le plateau de jeu.
	 */
	public abstract void draw();
}