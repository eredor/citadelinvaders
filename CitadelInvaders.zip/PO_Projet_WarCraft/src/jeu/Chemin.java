package jeu;
import java.util.ArrayList;
import java.util.List;

public class Chemin {
	
	// cellule = une des cases du plateau de jeu, reperee pas ses coordonnees (colonne,ligne) 
	//- N colonne/ligne entre 0 et (NB_SQUARE_X-1)/(NB_SQUARE_Y-1)
	static class Cellule {
		int colonne;
		int ligne;

		/**
		 * Constructeur d'une cellule
		 * @param colonne numero colonne : entre 0 et Main.NB_SQUARE_X - 1
		 * @param ligne numero ligne : entre 0 et Main.NB_SQUARE_Y - 1
		 */
		public Cellule(int colonne, int ligne) {
			this.colonne = colonne;
			this.ligne = ligne;
		}

		@Override
		public String toString() {
			return "Cellule [colonne=" + colonne + ", ligne=" + ligne + "]";
		}

	}

	// attributs de la classe Chemin 
	static List<Cellule> chemin;
	static Trajet trajet;

	/**
	 * constructeur de Chemin et creation d'un chemin particulier
	 */
	public Chemin(int lvl) {
		chemin = new ArrayList<Cellule>();
		makeChemin(lvl);
	}

	/**
	 * definition d'un chemin particulier  et creation du trajet associe
	 * @param lvl le level dont on souhaite construire le chemin 
	 */
	private void makeChemin(int lvl) {
		
		if(lvl==1) {
			// la premiere cellule = spawn
			chemin.add(new Cellule(7, 0));
			chemin.add(new Cellule(7, 1));
			chemin.add(new Cellule(8, 1));
			chemin.add(new Cellule(9, 1));
			chemin.add(new Cellule(9, 2));
			chemin.add(new Cellule(9, 3));
			chemin.add(new Cellule(8, 3));
			chemin.add(new Cellule(8, 4));
			chemin.add(new Cellule(8, 5));
			chemin.add(new Cellule(7, 5));
			chemin.add(new Cellule(7, 6));
			chemin.add(new Cellule(7, 7));
			chemin.add(new Cellule(7, 8));
			chemin.add(new Cellule(6, 8));
			chemin.add(new Cellule(5, 8));
			chemin.add(new Cellule(5, 7));
			chemin.add(new Cellule(5, 6));
			chemin.add(new Cellule(4, 6));
			chemin.add(new Cellule(3, 6));
			chemin.add(new Cellule(2, 6));
			chemin.add(new Cellule(1, 6));
			chemin.add(new Cellule(1, 5));
			chemin.add(new Cellule(1, 4));
			chemin.add(new Cellule(2, 4));
			chemin.add(new Cellule(2, 3));
			chemin.add(new Cellule(3, 3));
			chemin.add(new Cellule(3, 2));
			chemin.add(new Cellule(3, 1));
			chemin.add(new Cellule(4, 1));
			chemin.add(new Cellule(5, 1));
			chemin.add(new Cellule(5, 2));
			chemin.add(new Cellule(5, 3));
			// la cellule du chateau
			chemin.add(new Cellule(6, 3));
			// construction du trace automatique
			trajet = new Trajet();	
		}
		if(lvl==2) {
			// la premiere cellule = spawn
			chemin.add(new Cellule(7, 0));
			chemin.add(new Cellule(7, 1));
			chemin.add(new Cellule(8, 1));
			chemin.add(new Cellule(9, 1));
			chemin.add(new Cellule(10, 1));
			chemin.add(new Cellule(10, 2));
			chemin.add(new Cellule(10, 3));
			chemin.add(new Cellule(10, 4));
			chemin.add(new Cellule(10, 5));
			chemin.add(new Cellule(10, 6));
			chemin.add(new Cellule(10, 7));
			chemin.add(new Cellule(10, 8));
			chemin.add(new Cellule(10, 9));
			chemin.add(new Cellule(9, 9));
			chemin.add(new Cellule(8, 9));
			chemin.add(new Cellule(7, 9));
			chemin.add(new Cellule(6, 9));
			chemin.add(new Cellule(5, 9));
			chemin.add(new Cellule(4, 9));
			chemin.add(new Cellule(3, 9));
			chemin.add(new Cellule(2, 9));
			chemin.add(new Cellule(1, 9));
			chemin.add(new Cellule(0, 9));
			chemin.add(new Cellule(0, 8));
			chemin.add(new Cellule(0, 7));
			chemin.add(new Cellule(0, 6));
			chemin.add(new Cellule(0, 5));
			chemin.add(new Cellule(0, 4));
			chemin.add(new Cellule(0, 3));
			chemin.add(new Cellule(1, 3));
			chemin.add(new Cellule(2, 3));
			chemin.add(new Cellule(2, 4));
			chemin.add(new Cellule(2, 5));
			chemin.add(new Cellule(2, 6));
			chemin.add(new Cellule(3, 6));
			chemin.add(new Cellule(4, 6));
			chemin.add(new Cellule(5, 6));
			chemin.add(new Cellule(6, 6));
			chemin.add(new Cellule(7, 6));
			chemin.add(new Cellule(8, 6));
			chemin.add(new Cellule(8, 5));
			chemin.add(new Cellule(8, 4));
			chemin.add(new Cellule(8, 3));
			chemin.add(new Cellule(7, 3));

			// la cellule du chateau
			chemin.add(new Cellule(6, 3));
			// construction du trace automatique
			trajet = new Trajet();
		}
		
	}

	/**
	 * Dessin du chemin complet avec spawn et chateau 
	 * @param lvl le level dont on souhait dessiner le chemin
	 */
	public static void draw(int lvl) {
		for (Cellule cel : chemin) {
			switch(lvl) {
			case 1 : StdDraw.picture((0.5 + cel.colonne) / Main.NB_SQUARE_X, (0.5 + cel.ligne) / Main.NB_SQUARE_Y,
					"jeu/image/Textures/sol-foret-feuilles-texture-lvl1.jpg");
				break;
			case 2: StdDraw.picture((0.5 + cel.colonne) / Main.NB_SQUARE_X, (0.5 + cel.ligne) / Main.NB_SQUARE_Y,
					"jeu/image/Textures/water.gif");
				break;
			}

		}
		// Dessin du chateau - derniere cellule du chemin
		Cellule cel = chemin.get(chemin.size() - 1);
		StdDraw.picture((0.5 + cel.colonne) / Main.NB_SQUARE_X, (0.5 + cel.ligne) / Main.NB_SQUARE_Y,
				"jeu/image/Castle/chateau-lvl1.png");
		// Dessin du spawn - premiere cellule du chemin
		cel = chemin.get(0);
		StdDraw.picture((0.5 + cel.colonne) / Main.NB_SQUARE_X, (0.5 + cel.ligne) / Main.NB_SQUARE_Y,
				"jeu/image/Textures/pavé.jpg");
	}

	/**
	 * @return the chemin
	 */
	public static List<Cellule> getChemin() {
		return chemin;
	}

	/**
	 * @return the trajet
	 */
	public Trajet getTrajet() {
		return trajet;
	}

}
