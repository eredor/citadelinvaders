package jeu;
import java.util.ArrayList;
import java.util.List;

//Trajet suivi par les monstres : liste de points en coord reelles (0.0 a 1.0)
public class Trajet {

	//Le trajet est constitue d'une liste de Positions (en coord.normalisees)
	List<Position> pxy;

	/**
	 * Constructeur du trajet : calcule les Positions a partir des cellules definissant le chemin
	 */
	public Trajet() {
		pxy = new ArrayList<Position>();
		makeTrajet();
	}

	/**
	 * Calcule les Positions a partir des cellules definissant le chemin
	 * colonne et ligne : coord entieres - entre 0 et (NB_SQUARE_X-1)/(NB_SQUARE_Y-1)
	 * Positions x,y : coord reelles  normalisees (entre 0.0 et 1.0) 
	 */
	private void makeTrajet() {
		// on parcourt les cellules du chemin pour calculer les sommets du trajet
		for (Chemin.Cellule cel : Chemin.getChemin()) {
			pxy.add(new Position(((0.5 + cel.colonne) / Main.NB_SQUARE_X), ((0.5 + cel.ligne) / Main.NB_SQUARE_Y)));
		}
	}

	/**
	 * @return la liste pxy
	 */
	public List<Position> getPxy() {
		return pxy;
	}

}
