package jeu;
public class BaseMonster extends Monster {

	//Informations concernant le monstre de base: sa vitesse, ses points de vie, sa recompense et son apparence
	static final double SPEED_BASEMONSTER = 0.01;
	static final int HP_BASEMONSTER = 5;
	static final int REWARD_BASEMONSTER = 5;
	final int level;
	
	/**
	 *Constructeur du monstre de base
	 * @param p la postion du monstre
	 * @parem lvl le level joue par le joueur
	 */
	public BaseMonster(Position p, int lvl) {
		super(p, SPEED_BASEMONSTER, HP_BASEMONSTER, REWARD_BASEMONSTER, lvl);
		level = lvl;
	}

	/**
	 * Constructeur du monstre de base apres la premiere vague
	 * @param p la postion du monstre
	 * @param modifier permet d'ajuster la difficulte en fonction de la vague
	 * @parem lvl le level joue par le joueur
	 */
	public BaseMonster(Position p, int modifier, int lvl) {
		super(p, SPEED_BASEMONSTER + modifier * 0.01, HP_BASEMONSTER + modifier * 8, REWARD_BASEMONSTER, lvl);
		level = lvl;
	}

	/**
	 * Affiche un monstre terrestre
	 * Le monstre est represente par un goblin dans le level 1
	 * Le monstre est represente par un pirhana dans le level 2
	 */
	@Override
	public void draw() {
		switch(level) {
		case 1 : StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/perrongoblin/perrongoblin.gif");
			break;
		case 2 : StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/pirhana/pirhana.gif");
			break;
		}
	}
}
