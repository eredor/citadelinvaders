package jeu;

public class ShootingMonster extends Monster {

	//Informations concernant le monstre de base: sa vitesse, ses points de vie, sa recompense,
	//le temps de rechargement entre chacune de ses attaques, son attaque, sa portee et son apparence
	static final double SPEED_SHOOTINGMONSTER = 0.02;
	static final int HP_SHOOTINGMONSTER = 5;
	static final int REWARD_SHOOTINGMONSTER = 8;
	static final int REC_SHOOTINGMONSTER = 30;
	static final int ATK_SHOOTINGMONSTER = 1;
	static final double REACH_SHOOTINGMONSTER = 0.2;
	final int level;
	
	/**
	 * Constructeur d'un monstre qui tire
	 * @param p la position du monstre
	 * @parem lvl le level joue par le joueur
	 */
	public ShootingMonster(Position p, int lvl) {
		super(p, SPEED_SHOOTINGMONSTER, HP_SHOOTINGMONSTER, REWARD_SHOOTINGMONSTER, REACH_SHOOTINGMONSTER, 
				REC_SHOOTINGMONSTER, ATK_SHOOTINGMONSTER, lvl);
		level = lvl;
	}
	
	/**
	 *  Constructeur d'un monstre qui tire apres la premiere vague
	 * @param p la postion du monstre
	 * @param modifier permet d'ajuster la difficulte en fonction de la vague
	 * @parem lvl le level joue par le joueur
	 */
	public ShootingMonster(Position p, int modifier, int lvl) {
		super(p, SPEED_SHOOTINGMONSTER + modifier * 0.01, HP_SHOOTINGMONSTER + modifier * 8, REWARD_SHOOTINGMONSTER,
				REACH_SHOOTINGMONSTER + modifier*0.001, REC_SHOOTINGMONSTER, ATK_SHOOTINGMONSTER + modifier, lvl);
		level = lvl;
	}
	
	/**
	 * Affiche un shooting monster
	 * Le monstre est represente par un nain avec un lance pierre dans le level 1
	 * Le monstre est represente par une crevette dans le level 2
	 */
	public void draw() {
		switch(level) {
		case 1 : StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/nain-lance-pierre/nain.gif");
			break;
		case 2 : StdDraw.picture(p.getX(), p.getY(), "jeu/image/Monsters/shrimp/shrimp.gif");
			break;
		}
	}
}
