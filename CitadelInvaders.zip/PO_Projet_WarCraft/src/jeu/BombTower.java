package jeu;
public class BombTower extends Tower {

	//Informations concernant la tour a bombe: son cout, temps de recharchement,
	//sa portée, son identifiant determinant son type de projectile, ses points de vie
	static final int COST_BOMBTOWER =  60;
	static final int REC_BOMBTOWER =  20;
	static final double REACH_BOMBTOWER =  0.2;
	static final int ID_BOMBTOWER =  2;
	static final int HPMAX_BOMBTOWER =  15;

	/**
	 * Constructeur de la tour a bombe
	 * @param p la position de la tour
	 */
	public BombTower(Position p) {
		super(p, COST_BOMBTOWER, REC_BOMBTOWER, REACH_BOMBTOWER, ID_BOMBTOWER, HPMAX_BOMBTOWER);
	}

	/**
	 * Affiche une tour de bombe en mouvement si elle est fonctionnelle,
	 * une image fixe sinon
	 */
	@Override
	public void draw() {
		if(statut) StdDraw.picture(p.getX(), p.getY(),"jeu/image/BombTower/tour-bombe.gif");
		else StdDraw.picture(p.getX(), p.getY(),"jeu/image/BombTower/tour-bombe-1.png");
	}


}
