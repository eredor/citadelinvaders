package jeu;

public class IceTower extends Tower {

	//Informations concernant la tour de glace: son cout, temps de recharchement,
	//sa portée, son identifiant determinant son type de projectile, ses points de vie
	static final int COST_ICETOWER =  120;
	static final int REC_ICETOWER =  100;
	static final double REACH_ICETOWER =  0.2;
	static final int ID_ICETOWER =  3;
	static final int HPMAX_ICETOWER =  2;
	
	/**
	 * Constructeur de la tour de glace
	 * @param p la position de la tour
	 */
	public IceTower(Position p) {
		super(p, COST_ICETOWER, REC_ICETOWER, REACH_ICETOWER, ID_ICETOWER, HPMAX_ICETOWER);
	}
	

	/**
	 * Affiche une tour de glace en mouvement si elle est fonctionnelle,
	 * une image fixe sinon
	 */
	@Override
	public void draw() {
		if(statut) StdDraw.picture(p.getX(), p.getY(), "jeu/image/IceTower/tour-neige.gif");
		else StdDraw.picture(p.getX(), p.getY(), "jeu/image/IceTower/tour-neige-1.png");
	}
}
