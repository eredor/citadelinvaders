package jeu;

public class LaserTower extends Tower {
	
	//Informations concernant la tour laser: son cout, temps de recharchement,
	//sa portée, son identifiant determinant son type de projectile, ses points de vie
	static final int COST_LASERTOWER =  200;
	static final int REC_LASERTOWER =  0;
	static final double REACH_LASERTOWER =  0.3;
	static final int ID_LASERTOWER =  5;
	static final int HPMAX_LASERTOWER =  5;
	
	/**
	 * Constructeur de la tour laser
	 * @param p la position de la tour
	 */
	public LaserTower(Position p) {
		super(p, COST_LASERTOWER, REC_LASERTOWER, REACH_LASERTOWER, ID_LASERTOWER, HPMAX_LASERTOWER);
	}
	
	/**
	 * Affiche une tour de laser en mouvement si elle est fonctionnelle,
	 * une image fixe sinon
	 */
	@Override
	public void draw() {	
		if(statut) StdDraw.picture(p.getX(), p.getY(),"jeu/image/LaserTower/tour-laser.gif");		
		else StdDraw.picture(p.getX(), p.getY(),"jeu/image/LaserTower/tour-laser-1.png");		
	}
}
