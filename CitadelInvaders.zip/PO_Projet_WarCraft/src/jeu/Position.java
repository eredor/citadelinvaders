package jeu;
public class Position {

	// Attributs : coordonnees reelles normalises selon les axes X et Y
	private double x;
	private double y;

	/**
	 * Classe qui permet d'avoir la position sur l'axe des x et des y des monstres
	 * et des tours - coordonnees normalisees entre 0.0 et 1.0
	 * 
	 */
	public Position() {
		this.x = 0.0;
		this.y = 0.0;
	}

	/**
	 * Classe qui permet d'avoir la position sur l'axe des x et des y des monstres
	 * et des tours - coordonnees normalisees entre 0.0 et 1.0
	 * 
	 * @param x coord selon axe X en normalise
	 * @param y coord selon axe Y en normalise
	 */
	public Position(double x, double y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * 
	 * @param p Position utilisee pour initialiser la nouvelle Position
	 */
	public Position(Position p) {
		x = p.x;
		y = p.y;
	}

	/**
	 * Determine si les positions de this et p sont identiques
	 * 
	 * @param p Position a comparer a this
	 * @return vrai si la position de this et celle de p sont identiques
	 */
	public boolean equals(Position p) {
		return ((Math.abs(x - p.x) + Math.abs(y - p.y)) < 0.0000001);
	}

	/**
	 * Mesure la distance euclidienne entre les positions de this et celle de p.
	 * 
	 * @param p Position a mesurer avec this
	 * @return la valeur de la distance euclidienne entre this et p
	 *         (coord.normalisees)
	 */
	public double dist(Position p) {
		return Math.sqrt(((x - p.x) * (x - p.x)) + ((y - p.y) * (y - p.y)));
	}

	/**
	 * Creation d'un vecteur deplacement entre deux iterations successives c'est un Objet
	 * Position avec un ajustement particulier (de qq%)
	 * 
	 * @param x deplacement sur axe X pour une iteration en coord. normalisees (0.0
	 *          a 1.0)
	 * @param y deplacement sur axe Y pour une iteration
	 * @return vecteur deplacement ajuste
	 */
	public static Position dep(double x, double y) {
		Position p = new Position(x, y);
		p.adjust();
		return p;
	}

	/**
	 * Ajuste la valeur du deplacement iteratif entre 2 cellules successives pour en
	 * faire l'inverse d'un entier, ainsi apres un nombre entier(!) d'iterations on
	 * se retrouve avec une tres grande precision sur le point d'arrivee du segment
	 * (centre cellule)
	 */
	private void adjust() {
		// le traitement concerne soit x, soit y, l'un des deux etant toujours nul
		// si deplacement rectiligne d'un centre de cellule a l'autre
		if (Math.abs(x) > 0.0000001) {
			x = ((1.0 / Main.NB_SQUARE_X) / ((int) ((1.0 / Main.NB_SQUARE_X) / x)));
		}
		if (Math.abs(y) > 0.0000001) {
			y = ((1.0 / Main.NB_SQUARE_Y) / ((int) ((1.0 / Main.NB_SQUARE_Y) / y)));
		}
	}

	/**
	 * Retourne l'attribut x de la position
	 * 
	 * @return the x
	 */
	public double getX() {
		return x;
	}

	/**
	 * Remplace l'attribut x de la position par la valeur entree en parametre
	 * 
	 * @param x the x to set
	 */
	public void setX(double x) {
		this.x = x;
	}

	/**
	 * Retourne l'attribut y de la position
	 * 
	 * @return the y
	 */
	public double getY() {
		return y;
	}

	/**
	 * Remplace l'attribut x de la position par la valeur entree en parametre
	 * 
	 * @param y the y to set
	 */
	public void setY(double y) {
		this.y = y;
	}

}
