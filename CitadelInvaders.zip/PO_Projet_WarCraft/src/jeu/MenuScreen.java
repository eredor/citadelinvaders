package jeu;

import java.awt.Font;
import java.awt.Rectangle;

public class MenuScreen {

	int width; //largeur
	int height; //longueur
	int nbSquareX; //nombre de cases en longueur
	int nbSquareY; //nombre de cases en largeur
	double squareWidth; //largeur d'une case
	double squareHeight; //longueur d'une case
	Rectangle playButton; //le bouton PLAY
	boolean menu; //vaut false quand on a clique sur le bouton play

	/**
	 * Constructeur de MenuScreen
	 * @param width la largeur de la fenetre
	 * @param height la hauteur de la fenetre
	 * @param nbSquareX le nombre de case en longeur
	 * @param nbSquareY  le nombre de case en largeur
	 */
	public MenuScreen(int width, int height, int nbSquareX, int nbSquareY) {
		this.width = width;
		this.height = height;
		this.nbSquareX = nbSquareX;
		this.nbSquareY = nbSquareY;
		squareWidth = (double) 1.0 / nbSquareX;
		squareHeight = (double) 1.0 / nbSquareY;
		StdDraw.setCanvasSize(width, height);
		StdDraw.enableDoubleBuffering();
		menu = true;
		playButton = new Rectangle(75, 300, 220, 220);
	}

	/**
	 * Dessine le fond
	 */
	public void drawBackground() {
		StdDraw.picture(0.5, 0.5, "jeu/image/Backgrounds/background-menu.jpg");

	}

	/**
	 * Affiche le texte
	 */
	public void drawText() {
		StdDraw.setPenColor(StdDraw.BLACK);
		Font font = new Font("Sans Serif", Font.BOLD, 20);
		StdDraw.setFont(font);
		StdDraw.text(0.5, 0.80, "𝓔𝓶𝓶𝓪 𝓓𝓮𝓶𝓾𝓻𝓮 & 𝓔𝓶𝓶𝓪 𝓡𝓮𝓭𝓸𝓻");

		font = new Font("Sans Serif", Font.BOLD, 50);
		StdDraw.setFont(font);
		StdDraw.text(0.5, 0.90, "Cιƚαԃҽʅ Iɳʋαԃҽɾʂ");

		StdDraw.setPenColor(StdDraw.YELLOW);
		StdDraw.text(0.18, 0.36, "ℙ𝕃𝔸𝕐");

	}

	/**
	 * Verifie que la souris est sur un rectangle
	 * @param mouseX coordonées x de la souris
	 * @param mouseY coordonnées y de la souris
	 * @param r le rectangle
	 * @return true si la souris est sur le rectangle
	 */
	public boolean contains(double mouseX, double mouseY, Rectangle r) {
		return (( mouseX >= r.getMinX()/1000 && mouseX <= r.getMaxX()/1000) && ( mouseY >= r.getMinY()/1000 && mouseY <= r.getMaxY()/1000));
	}

	/**
	 * Boucle du menu
	 */
	public void run() {
		while(menu) {
			drawBackground();
			drawText();
			StdDraw.show();	
			if ((StdDraw.isMousePressed()) && (contains(StdDraw.mouseX(), StdDraw.mouseY(), playButton))) {
				menu = false;
			}
		}
		StdDraw.pause(100);
		World w = new World(width, height, nbSquareX, nbSquareY, 1, 0, 1);
		w.run();
	}
}

