package jeu;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

public class Timer {

	private Instant debut;
	private long duree; // duree du timer en millisecondes
	/**
	 * Constructeur du Timer
	 * @param duree du timer
	 */
	public Timer(long duree) {
		this.duree = duree;
		restart();
	}
	
	/**
	 * Constructeur du Timer
	 * @param debut debut du Timer
	 * @param duree la duree du Timer
	 */
	public Timer(Instant debut, long duree) {
		this.debut = debut;
		this.duree = duree;
		restart();
	}
	
	/**
	 * Re enclenche le Timer
	 */
	public void restart() {
		debut = Instant.now();
	}
	
	/**
	 * Verifie que le Timer est fini (duree ecoulee)
	 * @return true si le Timer est fini
	 */
	public boolean hasFinished() {
		return (debut.compareTo((Instant.now().minus(duree, ChronoUnit.MILLIS))) < 0);
	}
	
	/**
	 * 
	 * @return la duree avant la fin du Timer
	 */
	public long timeLeft() {
		return duree - ChronoUnit.MILLIS.between(debut, Instant.now());
	}
}
