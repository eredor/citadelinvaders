package jeu;
public class ArrowTower extends Tower {
	
	//Informations concernant la tour d'archer: son cout, temps de recharchement,
	//sa portée, son identifiant determinant son type de projectile, ses points de vie
	static final int COST_ARROWTOWER =  50;
	static final int REC_ARROWTOWER =  15;
	static final double REACH_ARROWTOWER =  0.3;
	static final int ID_ARROWTOWER =  1;
	static final int HPMAX_ARROWTOWER =  10;
	
	/**
	 * Constructeur de la tour d'archer
	 * @param p la position de la tour
	 */
	public ArrowTower(Position p) {
		super(p, COST_ARROWTOWER, REC_ARROWTOWER, REACH_ARROWTOWER, ID_ARROWTOWER, HPMAX_ARROWTOWER);
	}
	
	/**
	 * Affiche une tour d archer en mouvement si elle est fonctionnelle,
	 * une image fixe sinon
	 */
	@Override
	public void draw() {
		if(statut) StdDraw.picture(p.getX(), p.getY(), "jeu/image/TourArcher/tour-archer.gif");
		else StdDraw.picture(p.getX(), p.getY(), "jeu/image/TourArcher/tour-archer-1.png");
	}

}
