package jeu;
/**
 * 
 * @author Emma Demure & Emma Redor
 * 
 */
public class Main {

	//Taille de la fenetre de jeu
	static final int WIDTH =1000;
	static final int HEIGHT = 800;
	//Nombre de cases en largeur et en longueur
	static final int NB_SQUARE_X = 11;
	static final int NB_SQUARE_Y = 11;
	//Case de depart
	static final int START_X = 1;
	static final int START_Y = 0;   
	
	public static void main(String[] args) {
		MenuScreen m = new MenuScreen(WIDTH, HEIGHT, NB_SQUARE_X, NB_SQUARE_Y);
		m.run();
	}
}

