package jeu;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;


public class World {
	
	//MONSTRES
	//L'ensemble des monstres, pour gerer (notamment) l'affichage
	static List<Monster> monsters;
	//Le nombre de monstres de la vague pas encore crees
	int nbMonstersWave;
	//Le chemin suivi par les monstres
	Chemin chemin;
	//Position par laquelle les monstres vont venir
	Position spawn;
	//Timer Monster
	final long TIME_RECHARGE_MONSTER = 2000; // valeur initiale
	long deltaTimeRechargeTimerMonster = 400; // valeur initiale
	long initDureeTimerMonster = TIME_RECHARGE_MONSTER; // valeur initiale
	long dureeTimerMonster = TIME_RECHARGE_MONSTER; // valeur initiale
	long deltaDureeTimerMonster = 150; // variation de la duree - freq apparition aug.
	
	//TOURS
	//L'ensemble des tours, pour gerer (notamment) l'affichage
	static List<Tower> towers;
	
	//PROJECTILES
	//L'ensemble des projectiles, pour gerer (notamment) l'affichage
	static List<Projectile> projectiles;
	
	//PLATEAU DE JEU
	int width; //largeur
	int height; //longueur
	int nbSquareX; //nombre de cases en longueur
	int nbSquareY; //nombre de cases en largeur
	double squareWidth; //largeur d'une case
	double squareHeight; //longueur d'une case
	int lvl; //le level de la map

	//INFORMATIONS DU JOUEUR
	int life = 10; //ses points de vie
	final static int STARTLIFE = 10; //points de vie initial, permet de gérer l'affichage de la barre de vie
	//Gere l'affichage de la barre de vie
	boolean lessLife = false;
	double lifeGaugeLength = 0.0905;
	double lifeGaugeHeight = 0.0105;
	double redBar = 0;
	//Or du joueur
	int gold = 100;
	//Commande sur laquelle le joueur appuie (sur le clavier)
	char key;
	
	//Condition pour terminer la partie
	boolean end = false;
	//Boolean valant true si la partie est en cours, false si elle est sur 'pause'
	boolean start;
	//Boolean valant true si la partie est gagnee
	boolean win = false;
	//Boolean valant true si la partie est perdue
	boolean lose = false;

	//VAGUES
	int nbWave; //numero de la vague en cours
	int typeWave; //type de monstres de la vague
	boolean waveFinished; //etat de la vague
	Random rnd;
	Timer timerWave; //timer entre chaque vague
	Timer timerMonster; //timer entre chaque monstre 
	long timerWaveLeft; //duree avant le debut de la prochaine vague
	long timerMonsterLeft; //duree avant l'apparition du prochain monstre
	
	/**
	 * Initialisation du monde en fonction de la largeur, la hauteur et le nombre de
	 * cases donnees
	 * 
	 * @param width
	 * @param height
	 * @param nbSquareX
	 * @param nbSquareY
	 * @param startSquareX
	 * @param startSquareY
	 */
	public World(int width, int height, int nbSquareX, int nbSquareY, int startSquareX, int startSquareY, int lvl) {
		this.width = width;
		this.height = height;
		this.nbSquareX = nbSquareX;
		this.nbSquareY = nbSquareY;
		this.lvl = lvl;
		squareWidth = (double) 1.0 / nbSquareX;
		squareHeight = (double) 1.0 / nbSquareY;
		StdDraw.setCanvasSize(width, height);
		StdDraw.enableDoubleBuffering();
		// construction du chemin suivi par les monstres
		chemin = new Chemin(lvl);
		spawn = new Position(startSquareX * squareWidth + squareWidth / 2,
				startSquareY * squareHeight + squareHeight / 2);
		monsters = new ArrayList<Monster>();
		towers = new ArrayList<Tower>();
		projectiles = new ArrayList<Projectile>();
		// gene aleatoire
		rnd = new Random();
		nbWave = 0;
		waveFinished = true;
		start = false;
	}

	/**
	 * Permet de gerer les vagues et l'apparition des monstres
	 * 
	 */
	public void waveMaker() {
		if(life==1) {
			StdDraw.clear(StdDraw.BLACK);
			StdDraw.picture(0.5, 0.5, "jeu/image/Menu/loser-screen.png");
			System.out.println("YOU LOSE !");
			System.out.println("PRESS T TO TRY AGAIN !");
			end = true;
			lose = true;
		}
				
		//vague terminee ?
		if(waveFinished) {
			//le temps entre la vague precedente et la vague suivante est il ecoule ?
			if(timerWave.hasFinished()) {
				nbWave++ ;
				nbMonstersWave = (int) ( 4 + nbWave*2*lvl);
				//detemine le type de monstre de cette vague
				int z = rnd.nextInt(2); // z uniformement distribue sur 0..2
				switch (z) {
				case 0 : typeWave = 0; //BASEMONSTER
				break;
				case 1 : typeWave = 1; //FLYINGMONSTER
				break;
				}
				//commence la vague
				waveFinished = false;
				//le premier monstre apparait de suite
				timerMonster = null;
				timerMonster = new Timer(0);
			}
		}
		else {
			//il reste des monstres a ajouter ?
			if(nbMonstersWave != 0) {
				//le temps entre le monstre precedent et le monstre a ajouter est ecoule ?
				if(timerMonster.hasFinished()) {
					//fait apparaitre un monstre du bon type
					nbMonstersWave-- ;
					switch (typeWave) {
					case 0 : 
						if (nbWave == 1) World.monsters.add(new BaseMonster(new Position(), lvl));
						else World.monsters.add(new BaseMonster(new Position(), nbWave, lvl ));
						break;
					case 1 : 
						if (nbWave == 1) World.monsters.add(new FlyingMonster(new Position(), lvl));
						else World.monsters.add(new FlyingMonster(new Position(), nbWave, lvl ));
						break;
					}
					//fait apparaitre un Shooting Monster ou un Boss si les conditions
					//sont verifiees
					if ((nbWave == 5) && (nbMonstersWave == 4)) World.monsters.add(new BossMonster(new Position(), lvl));
					if(nbMonstersWave == 3) World.monsters.add(new ShootingMonster(new Position(), nbWave, lvl));
					//determine quand va apparaitre le prochain monstre
					timerMonster = null;
					timerMonster = new Timer(dureeTimerMonster);
					dureeTimerMonster -= 20 + rnd.nextInt(180); //
					if (dureeTimerMonster < 200) {
						initDureeTimerMonster -= rnd.nextInt(200) + deltaTimeRechargeTimerMonster / 4;
						if (initDureeTimerMonster < 250)
							initDureeTimerMonster = rnd.nextInt(2000) + TIME_RECHARGE_MONSTER / 2;
						dureeTimerMonster = initDureeTimerMonster;
					}
					//enclenche le timer
					timerMonster.restart(); 
				}

			}
			else {
				//il y a des monstres en vie ?
				if (monsters.size() == 0) {
					waveFinished = true;
					if (nbWave == 5) {
						StdDraw.picture(0.5, 0.5, "jeu/image/Menu/win-screen.png");
						System.out.println("LEVEL COMPLETED !");
						end = true;
						win = true;
					}
					else {
					System.out.println("WAVE COMPLETED !");
					gold = gold + nbWave*3; //bonus d'or
					timerWave = null;
					timerWave = new Timer(10000); // 10s entre chaque vague
					}
				}
			}
		}
	}

	/**
	 * Pour chaque monstre de la liste de monstres de la vague, utilise la fonction update() de Monster. 
	 * Enleve le monstre de la carte s'il n'a plus de point de vie ou s'il a atteint le chateau.
	 * Si un monstre a reussi a atteindre le chateau, fait perdre un point de vie au joueur
	 * Si un monstre a ete abattu, le joueur empoche la recompense correspondante
	 * Modifie la position du monstre au cours du temps l'aide du param nextP.
	 */
	public void updateMonsters() {
		
		Iterator<Monster> i = monsters.iterator();
		Monster m;
		List<Monster> removed =  new ArrayList<Monster>();
		while (i.hasNext()) {
			m = i.next();
			m.update();
			if ((m.hp <= 0) || (m.reached)){
				if((m.reached) && life != 0) {
					life --;
					lessLife=true;
					redBar+=lifeGaugeLength/STARTLIFE;
				}
				if (life == 0) end = true;
				if(m.hp <= 0) {
					gold = gold + m.reward;
				}
				removed.add(m);
			}
			else {
				if (m.p.getX() < 0.0)
					m.p.setX(1.0);
				if (m.p.getX() > 1.0)
					m.p.setX(0.0);
				if (m.p.getY() < 0.0)
					m.p.setY(1.0);
				if (m.p.getY() > 1.0)
					m.p.setY(0.0);
			}
		}
		monsters.removeAll(removed);
	}

	/**
	 * Pour chaque tour de la liste de tours, utilise la fonction update() de Tower. 
	 */
	public void updateTowers() {
		Iterator<Tower> i = towers.iterator();
		Tower t;
		while (i.hasNext()) {
			t = i.next();
			t.update();
		}	
	 }
	
	/**
	 * Pour chaque projectile de la liste de projectiles de la vague, utilise la fonction update() de Projectile.
	 * Enleve les projectiles ayant atteint leur cible 
	 */
	public void updateProjectiles() {
		Iterator<Projectile> i = projectiles.iterator();
		Projectile p;
		List<Projectile> removed =  new ArrayList<Projectile>();
		while (i.hasNext()) {
			p = i.next();
			p.update();
			if (p.hit) removed.add(p);
		}
		projectiles.removeAll(removed);
	}
	
	/*
	 * Pour chaque tour sur le plateau, cherche une cible. 
	 * La tour ne trouve pas de cible si aucun monstre n'est a portee 
	 */
	public void findTarget() {
		for (Tower t: towers) {
			t.target = null;
			t.checkpointMax = 0;
			for (Monster m: monsters) {
				m.target = null;
				if((t.getClass() == BombTower.class) && (m.getClass() == FlyingMonster.class)) {
					continue;
				}
				if((t.getClass() == IceTower.class) && (m.frozen)) {
					continue;
				}
				if((t.getClass() == FireTower.class) && (m.burntDuration != 0)) {
					continue;
				}
				double distX = Math.abs(m.p.getX() - t.p.getX());
				double distY = Math.abs(m.p.getY() -  t.p.getY());
				double distance = Math.sqrt((distX*distX)+(distY*distY));
				if((distance < t.reach) && (t.checkpointMax < m.checkpoint)) {
					t.target = m;
					t.checkpointMax = m.checkpoint;	
				}
				if((m.getClass() == ShootingMonster.class) && (distance < m.reach) && (t.statut)) {
					m.target = t;
				}
			}
		}
	}
	
	/*
	 * Fait attaquer toutes les tours pretes a attaquer et ayant une cible.
	 * Dans le cas d une tour laser, demarre le laser.
	 * Dans les autres cas, lance un projectile.
	 */
	public void attack() {
		for (Tower t : towers) {
			if ((t.target != null) && (t.left == 0) && (t.statut)) {
					Projectile p = new Projectile(t, t.target, true);
					projectiles.add(p);
					t.left = t.rec ;
					
			}
		}
		for(Monster m : monsters) {
			if((m.getClass() == ShootingMonster.class) && (m.target != null) && (m.left == 0)) {
				Projectile p = new Projectile(m.target, m, false);
				projectiles.add(p);
				m.left = m.rec;
			}
		}
	}
	
	
	/**
	 * Verifie qu'une cellule n'est pas occupe par le chemin
	 * 
	 * @param list le chemin suivit par les monstres
	 * @param c la cellule dont on veut connaitre la disponibilite
	 * @return true si la cellule ne fait pas partie du chemin
	 */
	public static boolean isFree (Chemin list, Chemin.Cellule c) {
		for (int i = 0; i < Chemin.getChemin().size(); i++) {
			if((c.colonne == Chemin.getChemin().get(i).colonne) && (c.ligne == Chemin.getChemin().get(i).ligne)) return false;
		}
		return true;
	}
	
	/**
	 * Rend l'indice d'une tour dont la position est passee en parametre
	 * 
	 * @param list la liste des tours sur le plateau
	 * @param p la position dont l'on souhaite connaitre la disponibilite 
	 * @return l'indice de la tour dont la position est p. Si aucune tour n'a cette postion, retourne -1
	 */
	public static int isTower (List<Tower> list, Position p) {
		if(list != null) {
			for (int i = 0; i < list.size(); i++) {
				if((p.getX() == list.get(i).p.getX()) && (p.getY() == list.get(i).p.getY())) return i;
			}
		}
		return -1;
	}
	
	/**
	 * Concentre toutes les fonctions draw
	 * Permet d'afficher les monstres/tours/projectiles lorsque le jeu est en pause
	 */
	public void draw() {
		for(Monster m : monsters) m.draw();
		for(Tower t : towers) t.draw();
		for(Projectile p : projectiles) p.draw();
	}
	
	/**
	 * Definit le decors du plateau de jeu.
	 */
	public void drawBackground() {
		if(lvl==1) StdDraw.picture(0.5, 0.5, "jeu/image/Backgrounds/background-lvl1.jpg");
		if(lvl==2) StdDraw.picture(0.5, 0.5, "jeu/image/Backgrounds/background-lvl2.jpg");
	}

	/**
	 * Initialise le chemin sur la position du point de depart des monstres. Cette
	 * fonction permet d'afficher une route qui sera differente du decors.
	 */
	public void drawPath() {
		Position p = new Position(spawn);
		StdDraw.setPenColor(StdDraw.YELLOW);
		StdDraw.filledRectangle(p.getX(), p.getY(), squareWidth / 2, squareHeight / 2);
	}

	/**
	 * Affiche certaines informations sur l'ecran telles que les points de vie du
	 * joueur ou son or
	 */
	public void drawInfos() {
				
		double x = (0.5 + 6.0) / Main.NB_SQUARE_X;
		double y = (0.5 + 10.0) / Main.NB_SQUARE_X;
		double z = 0.22-redBar;					
		
		//Titre du niveau
		
		if(lvl==1) {
		StdDraw.setPenColor(StdDraw.YELLOW);
		StdDraw.text(x-0.1, y, "𝕃𝔼𝕍𝔼𝕃 𝟙 : 𝔾𝕝𝕦𝕥𝕥𝕠𝕟𝕪 𝕎𝕠𝕠𝕕𝕤");
		}
		
		if(lvl==2) {
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.text(x-0.1, y, "LEVEL 2 : AQUA JUNGLE");
		}
		
		//Dessin de la jauge de vie
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledRectangle(x-0.455, y+0.005, lifeGaugeLength, lifeGaugeHeight);
		StdDraw.setPenColor(StdDraw.GREEN);
		StdDraw.filledRectangle(x-0.455, y+0.005, lifeGaugeLength, lifeGaugeHeight);
		if(lessLife) {
			StdDraw.setPenColor(StdDraw.RED);
			StdDraw.filledRectangle(z, y+0.005, lifeGaugeLength/STARTLIFE+redBar, lifeGaugeHeight);
		}
		StdDraw.setPenColor(StdDraw.RED);
		StdDraw.picture(0.025, y, "jeu/image/HeartLifeBar/heart.gif");
		
		//Dessin de la jauge de "Gold"
		StdDraw.setPenColor(StdDraw.YELLOW);
		StdDraw.filledRectangle(x-0.455, y-0.035, lifeGaugeLength, lifeGaugeHeight);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.text(0.14, y-0.0359, gold + "€");
		StdDraw.picture(0.0255, y-0.035, "jeu/image/bourse/bourse.png");

	}

	/**
	 * Fonction qui recupere le positionnement de la souris et permet d'afficher une
	 * image de tour en temps lorsque le joueur appuie sur une des touches
	 * permettant la construction d'une tour.
	 * Si la souris survole une tour, affiche la portee de la tour en question
	 */
	public void drawMouse() {
		double normalizedX = (int) (StdDraw.mouseX() / squareWidth) * squareWidth + squareWidth / 2;
		double normalizedY = (int) (StdDraw.mouseY() / squareHeight) * squareHeight + squareHeight / 2;
		String image = null;
		double reach = 0.0;
		switch (key) {
		case 'a': 
			image = "jeu/image/TourArcher/tour-archer-1.png";
			reach = ArrowTower.REACH_ARROWTOWER;
			break;
		case 'b':
			image = "jeu/image/BombTower/tour-bombe-1.png";
			reach = BombTower.REACH_BOMBTOWER;
			break;
		case 'f':
			image = "jeu/image/FireTower/tour-feu-1.png";
			reach = FireTower.REACH_FIRETOWER;
			break;
		case 'i':
			image = "jeu/image/IceTower/tour-neige-1.png";
			reach = IceTower.REACH_ICETOWER;
			break;
		case 'l':
			image = "jeu/image/LaserTower/tour-laser-1.png";
			reach =  LaserTower.REACH_LASERTOWER;
			break;
		}
		if (image != null)
			StdDraw.picture(normalizedX, normalizedY, image);
			StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
			StdDraw.circle(normalizedX, normalizedY, reach);
		int indice = isTower(towers, new Position(normalizedX, normalizedY));
		if (indice != -1) {
			StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
			StdDraw.circle(World.towers.get(indice).p.getX(), World.towers.get(indice).p.getY(), World.towers.get(indice).reach);
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.text(normalizedX, normalizedY, "Level "+ World.towers.get(indice).lvl);
		}
	}
	
	/**
	 * Recupere la touche appuyee par l'utilisateur et affiche les informations pour
	 * la touche selectionnee
	 * 
	 * @param key la touche utilisee par le joueur
	 */
	public void keyPress(char key) {
		key = Character.toLowerCase(key);
		this.key = key;
		switch (key) {
		case 'a':
			System.out.println("Arrow Tower selected (50g).");
			break;
		case 'b':
			System.out.println("Bomb Tower selected (60g).");
			break;	
		case 'i':
			System.out.println("Ice Tower selected (120g).");
			break;
		case 'f':
			System.out.println("Fire Tower selected (120g).");
			break;
		case 'l':
			System.out.println("Laser Tower selected (200g).");
			break;		
		case 'e':
			if(win||lose) {
				MenuScreen m = new MenuScreen(width, height, nbSquareX, nbSquareY);
				m.run();
			}
			else System.out.println("Evolution selected (40g).");
			break;	
		case 'r' :
			if(lose) {
				World w = new World(width, height, nbSquareX, nbSquareY, 1, 0, lvl);
				w.run();
			}
			else System.out.println("Repair selected, please select a tower.");
			break;
			
		case 's': pause();
			break;
		case 'q':
			System.out.println("Exiting.");
			System.exit(0);
			break;
		case'n': if(win && (lvl == 1)) {
			World w = new World(width, height, nbSquareX, nbSquareY, 1, 0, 2);
			w.run();
		}
			break;
		case 't': if(lose) {
			World w = new World(width, height, nbSquareX, nbSquareY, 1, 0, lvl);
			w.run();
		}
			break;
		case '?' : 
			String cheats = "Cheats List :" + "\n";
			cheats += "1 : life + 10" + "\n";
			cheats += "2 : gold + 100" + "\n";
			cheats += "3 : Complete the current wave" + "\n";
			cheats += "4 : Upgrade all towers to max level" + "\n";
			cheats += "5 : Monsters on map are level 4" + "\n";
			System.out.println(cheats);
			break;
		case '1' : life += 10;
			break;
		case '2' : gold += 100;
			break;
		case '3' : 
			nbMonstersWave = 0;
			World.monsters.clear();
			break;
		case '4' : 
			for (Tower t : towers) t.lvl = 4;
			break;
		case '5' : 
			for (Monster m : monsters) {
				m.speed = m.speed * 4;
				m.hp = m.hp * 4;
			}
			break;
		}
	}

	/**
	 * Verifie lorsque l'utilisateur clique sur sa souris qu'il peut: 
	 * 	- Ajouter une tour la position indiquee par la souris. 
	 * 	- Ameliorer une tour existante.
	 * @param x la position horizontale de la souris
	 * @param y la position verticale de la souris
	 */
	public void mouseClick(double x, double y) {
		double normalizedX = (int) (x / squareWidth) * squareWidth + squareWidth / 2;
		double normalizedY = (int) (y / squareHeight) * squareHeight + squareHeight / 2;
		Position p =  new Position(normalizedX, normalizedY);
		int pCol =  (int) (Math.round(normalizedX * Main.NB_SQUARE_X - 0.5));
		int pLi =  (int) (Math.round(normalizedY * Main.NB_SQUARE_Y - 0.5));
		Chemin.Cellule c = new Chemin.Cellule(pCol, pLi);
		int indice = isTower(towers, p);
		if(indice != -1) {
			Tower t = World.towers.get(indice);
			switch(key) {
			case 'e' :
				if((gold >= 40 + 10*t.lvl) && (t.statut)) {
					gold = gold - (40 + 10*t.lvl);
					t.levelUp();
					key = Character.MIN_VALUE;
				}
				else if (t.lvl == 4) System.out.println("La tour a atteint le niveau maximum");
				else if (!t.statut) System.out.println("Repair the tower first");
				else System.out.println("Not enough gold");
				break;
			case 'r' :
				if(t.hp != t.hpmax) {
					int cost;
					if(t.statut) {
						cost = t.hpmax - t.hp;
					}
					else cost = t.hpmax + t.lvl * 10;
					if(gold - cost >= 0) {
						t.repair();
						gold -= cost;
					}
					else System.out.println("Not enough gold.");
				}
				else System.out.println("Tower's hp are maximum.");
			}
		}
		else {
			if ((isFree(chemin, c)) && (indice == -1)) {
				switch (key) {
				case 'a': 
					if(gold >= ArrowTower.COST_ARROWTOWER) {
						gold -= ArrowTower.COST_ARROWTOWER;
						World.towers.add(new ArrowTower(new Position(p)));
						key = Character.MIN_VALUE;
					}
					break;
				case 'b': 
					if(gold >= BombTower.COST_BOMBTOWER) {
						gold -= BombTower.COST_BOMBTOWER;
						World.towers.add(new BombTower(new Position(p)));
						key = Character.MIN_VALUE;
					}
					break;
				case 'f': 
					if(gold >= FireTower.COST_FIRETOWER) {
						gold -= FireTower.COST_FIRETOWER;
						World.towers.add(new FireTower(new Position(p)));
						key = Character.MIN_VALUE;
					}
					break;
				case 'i': 
					if(gold >= IceTower.COST_ICETOWER) {
						gold -= IceTower.COST_ICETOWER;
						World.towers.add(new IceTower(new Position(p)));
						key = Character.MIN_VALUE;
					}
					break;
				case 'l': 
					if(gold >= LaserTower.COST_LASERTOWER) {
					gold -= LaserTower.COST_LASERTOWER;
					World.towers.add(new LaserTower(new Position(p)));
					key = Character.MIN_VALUE;
					}
					break;
				}
			}
		}
	}

	/**
	 * Gere la fonction pause du jeu
	 * Quand le jeu est mis en pause, garde en memoire le temps restant des differents timers
	 * Quand le jeu reprend, relance les differents timers avec pour duree la duree correspondante celle
	 * enregistree precedemment
	 */
	public void pause() {
		if (start)  {
			start = false;
			System.out.println("Game paused");
			 timerWaveLeft = timerWave.timeLeft();
			 timerMonsterLeft = timerMonster.timeLeft();
			 for(Monster m: monsters) {
				 if(m.frozen) m.frozenLeft = m.frozenTimer.timeLeft();
				 if(m.burntDuration != 0) {
					 m.burntTLeft = m.burntTimer.timeLeft();
					 m.burntDLeft = m.burntDuration;
				 }
			 }
			 
		}
		else  {
			start = true;
			if (nbWave == 0)  {
				System.out.println("Starting game!");
				timerWave = new Timer(2000); //20s avant la premiere vague
			}
			else {
				System.out.println("Resume game");
				timerWave = new Timer(timerWaveLeft);
				timerMonster = new Timer(timerMonsterLeft);
				 for(Monster m: monsters) {
					 if(m.frozenLeft != 0) {
						 m.frozenTimer = new Timer(m.frozenLeft);
						 m.frozenLeft = 0;
					 }
					 if(m.burntDLeft != 0) {
						 m.burntTimer = new Timer(m.burntTLeft);
						 m.burntDuration = m.burntDLeft;
						 m.burntDLeft = 0;
					 }
				 }
			}
			
		}
	}
		
	/**
	 * Met a jour toutes les informations du plateau de jeu ainsi que les deplacements des monstres
	 * et les attaques des tours et des monstres si le jeu n'est pas en pause.
	 * 
	 * @return les points de vie restants du joueur
	 */
	public int update() {
		drawBackground();
		Chemin.draw(lvl);
		drawInfos();
		draw();
		if (start)  {
			waveMaker();
			updateMonsters();
			updateTowers();
			updateProjectiles();
			findTarget();
			attack();
			drawMouse();
		}
		return life;
	}

	/**
	 * Comme son nom l'indique, cette fonction permet d'afficher dans le terminal
	 * les differentes possibilitoffertes au joueur pour interagir avec le
	 * clavier
	 */
	public void printCommands() {
		System.out.println("Press A to select Arrow Tower (cost 50g).");
		System.out.println("Press B to select Cannon Tower (cost 60g).");
		System.out.println("Press F to select Fire Tower (cost 120g).");
		System.out.println("Press I to select Ice Tower (cost 120g).");
		System.out.println("Press L to select Laser Tower (cost 200g).");
		System.out.println("Press E to update a tower (cost 40g).");
		System.out.println("Press S to start/pause.");
		System.out.println("Press Q to quit the game");
		System.out.println("Click on the grass to build it.");
		
	}
	
	/**
	 * Recupere la touche entree au clavier ainsi que la position de la souris et
	 * met a jour le plateau en fonction de ces interactions
	 */
	public void run() {
		printCommands();
		while (!end) {

			StdDraw.clear();
			if (StdDraw.hasNextKeyTyped()) {
				keyPress(StdDraw.nextKeyTyped());
			}

			if ((StdDraw.isMousePressed()) && start) {
				mouseClick(StdDraw.mouseX(), StdDraw.mouseY());
				StdDraw.pause(50);
			}
			
			update();
			StdDraw.show();
			
			StdDraw.pause(2);
		}
		while(win || lose) {
			StdDraw.clear();
			if (StdDraw.hasNextKeyTyped()) {
				keyPress(StdDraw.nextKeyTyped());
			}
			
		}
	}
}
