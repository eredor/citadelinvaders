package jeu;

public class FireTower extends Tower {

	//Informations concernant la tour de feu: son cout, temps de recharchement,
	//sa portée, son identifiant determinant son type de projectile, ses points de vie
	static final int COST_FIRETOWER = 120;
	static final int REC_FIRETOWER =  100;
	static final double REACH_FIRETOWER =  0.2;
	static final int ID_FIRETOWER =  4;
	static final int HPMAX_FIRETOWER =  8;
	int imgFireTower; //gere l'affichage
	Timer timerFireTower; //indique quand changer d'image 
	 

	/**
	 * Constructeur de la tour de feu
	 * @param p la position de la tour
	 */
	public FireTower(Position p) {
		super(p, COST_FIRETOWER, REC_FIRETOWER, REACH_FIRETOWER, ID_FIRETOWER, HPMAX_FIRETOWER);
		imgFireTower = 1;
		timerFireTower = new Timer(500);
	}

	/**
	 * Affiche une tour de feu, le timer fait changer l'image (comme un gif) si la tour
	 * est fonctionnelle, sinon l'image ne change pas
	 */
	@Override
	public void draw() {
		if(timerFireTower.hasFinished() && statut) {
			timerFireTower.restart();
			if(imgFireTower == 3) imgFireTower = 1;
			else imgFireTower++;
		}
		switch (imgFireTower) {
		case 1 : StdDraw.picture(p.getX(), p.getY(), "jeu/image/FireTower/tour-feu-1.png");
				break;
		case 2:  StdDraw.picture(p.getX(), p.getY(), "jeu/image/FireTower/tour-feu-2.png");
				break;
		case 3:  StdDraw.picture(p.getX(), p.getY(), "jeu/image/FireTower/tour-feu-3.png");
				break;
		
		}		  	  
	}
}
